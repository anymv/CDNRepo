from .download_helper import DownloadHelper
import time
from bot import download_dict_lock, download_dict
from ..status_utils.tidal_dl_download_status import TidalDLDownloadStatus
import logging
import re
import threading
import subprocess
import requests
from bs4 import BeautifulSoup
import os

LOGGER = logging.getLogger(__name__)


class MyLogger:
    def __init__(self, obj):
        self.obj = obj

    def debug(self, msg):
        LOGGER.debug(msg)
        # Hack to fix changing changing extension
        match = re.search(r'.ffmpeg..Merging formats into..(.*?).$', msg)
        if match and not self.obj.is_playlist:
            self.obj.name = match.group(1)

    @staticmethod
    def warning(msg):
        LOGGER.warning(msg)

    @staticmethod
    def error(msg):
        LOGGER.error(msg)


class TidalDLHelper(DownloadHelper):
    def __init__(self, listener):
        super().__init__()
        self.__name = ""
        self.__start_time = time.time()
        self.__listener = listener
        self.__gid = ""
        self.opts = {
            'progress_hooks': [self.__onDownloadProgress],
            'logger': MyLogger(self),
            'usenetrc': True
        }
        self.__download_speed = 0
        self.download_speed_readable = ''
        self.downloaded_bytes = 0
        self.size = 0
        self.is_playlist = False
        self.last_downloaded = 0
        self.is_cancelled = False
        self.vid_id = ''
        self.__resource_lock = threading.RLock()

    @property
    def download_speed(self):
        with self.__resource_lock:
            return self.__download_speed

    @property
    def gid(self):
        with self.__resource_lock:
            return self.__gid

    def __onDownloadProgress(self, d):
        if self.is_cancelled:
            raise ValueError("Cancelling Download..")
        if d['status'] == "finished":
            if self.is_playlist:
                self.last_downloaded = 0
        elif d['status'] == "downloading":
            with self.__resource_lock:
                self.__download_speed = d['speed']
                if self.is_playlist:
                    progress = d['downloaded_bytes'] / d['total_bytes']
                    chunk_size = d['downloaded_bytes'] - self.last_downloaded
                    self.last_downloaded = d['total_bytes'] * progress
                    self.downloaded_bytes += chunk_size
                    try:
                        self.progress = (self.downloaded_bytes / self.size) * 100
                    except ZeroDivisionError:
                        pass
                else:
                    self.download_speed_readable = d['_speed_str']
                    self.downloaded_bytes = d['downloaded_bytes']

    def __onDownloadStart(self):
        with download_dict_lock:
            download_dict[self.__listener.uid] = TidalDLDownloadStatus(self, self.__listener)

    def __onDownloadComplete(self):
        self.__listener.onDownloadComplete()

    def onDownloadError(self, error):
        self.__listener.onDownloadError(error)

    def __linkparse(self,link):
        try:
            regex = re.findall('(\w+)://tidal.com/browse/(\w+)/(\w+)(?<=)', link)
            return regex[0][1], regex[0][2]
        except IndexError:
            self.onDownloadError(f"Only Tidal Links are Supported \n Ex : <code>https://tidal.com/browse/track/111610009?play=true</code> or \n<code>https://tidal.com/browse/track/111610009</code>")

    def NameParse(self, link, qual):
        tidaltype,tidalid = self.__linkparse(link)
        title =self.__titleparse(link)
        self.name = title+'-['+tidaltype+']-['+qual+']-['+tidalid+']'

    def __titleparse(self,link):
        NotFound = 'TIDAL Browse - High Fidelity Music Streaming'
        data=requests.get(link)
        bssoup = BeautifulSoup(data.text, 'html.parser') 
        tid =' on TIDAL'
        for title in bssoup.find_all('title'): 
            tit = title.get_text()
            if tit == NotFound:
                self.onDownloadError('Not a Album/Playlist/Artist/Track on Tidal\nCheck the Link')
            else:
                if tid in tit:
                    new = tit.replace(tid,'')
        return new

    def __download(self, link, path):
        try:
            down = subprocess.run(["tidal-dl", "-l", link]).returncode
            if down == 0:
                try:
                    os.rename(path+'/Tidal/',path+'/'+self.name+'/')
                    self.__onDownloadComplete()
                except FileNotFoundError:
                    self.onDownloadError('Internal Error Occured')    
        except ValueError:
            LOGGER.info("Download Cancelled by User!")
            self.onDownloadError("Download Cancelled by User!")

    def add_download(self, link, path, qual):
        self.NameParse(link,qual)
        self.__onDownloadStart()
        LOGGER.info(f"Downloading with Tidal-DL: {link}")
        tidaltype,tidalid = self.__linkparse(link)
        self.__gid = f"{tidalid}{self.__listener.uid}"
        pathset = subprocess.run(["tidal-dl", "-o", path+'/Tidal/']).returncode
        qualset = subprocess.run(["tidal-dl", "-q", qual]).returncode
        self.__download(link,path)

    def cancel_download(self):
        self.is_cancelled = True
