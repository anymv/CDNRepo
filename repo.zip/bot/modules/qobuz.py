
from telegram.ext import CommandHandler, run_async
from telegram import Bot, Update
from bot import Interval, DOWNLOAD_DIR, DOWNLOAD_STATUS_UPDATE_INTERVAL, dispatcher, LOGGER
from bot.helper.ext_utils.bot_utils import setInterval
from bot.helper.telegram_helper.message_utils import update_all_messages, sendMessage, sendStatusMessage
from .mirror import MirrorListener
from bot.helper.mirror_utils.download_utils.qobuz_dl_download_helper import QobuzDLHelper
from bot.helper.telegram_helper.bot_commands import BotCommands
from bot.helper.telegram_helper.filters import CustomFilters
import threading



def _qobuz(bot: Bot, update: Update, args: list, isTar=False):
    try:
        link = args[0]
    except IndexError:
        msg = f"/{BotCommands.QobuzCommand} [Qobuz Track/Album/Playlist/Artist/Label Link] [quality] to mirror with Qobuz-dl.\n\n"
        msg += "\nLink Should be from play.qobuz.com"
        msg += "Example of quality :- '320Kbps-320','Lossless(16-Bit) - 16B','24Bit(96Khz-) - 24B','24Bit(96Khz+) - 24B+'.\nNote :- Quality is optional\n"
        msg += f"Ex: \n <code>https://play.qobuz.com/album/baemkikxzkj7b</code>"
        sendMessage(msg, bot, update)
        return
    try:
      qual = args[1]
    except IndexError:
      qual = "24B+"
    reply_to = update.message.reply_to_message
    if reply_to is not None:
        tag = reply_to.from_user.username
    else:
        tag = None

    listener = MirrorListener(bot, update, isTar, tag)
    qdl = QobuzDLHelper(listener)
    threading.Thread(target=qdl.add_download,args=(link, f'{DOWNLOAD_DIR}{listener.uid}', qual)).start()
    sendStatusMessage(update, bot)
    if len(Interval) == 0:
        Interval.append(setInterval(DOWNLOAD_STATUS_UPDATE_INTERVAL, update_all_messages))


@run_async
def QobuzTar(update, context):
    _qobuz(context.bot, update, context.args, True)


def Qobuz(update, context):
    _qobuz(context.bot, update, context.args)


mirror_handler = CommandHandler(BotCommands.QobuzCommand, Qobuz,
                                pass_args=True,
                                filters=CustomFilters.authorized_chat | CustomFilters.authorized_user)
tar_mirror_handler = CommandHandler(BotCommands.TarQobuzCommand, QobuzTar,
                                    pass_args=True,
                                    filters=CustomFilters.authorized_chat | CustomFilters.authorized_user)
dispatcher.add_handler(mirror_handler)
dispatcher.add_handler(tar_mirror_handler)
